-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Dec 13, 2021 at 11:50 AM
-- Server version: 8.0.27
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Pizzeria`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int NOT NULL,
  `activity_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `activity_img` varchar(255) NOT NULL,
  `activity_descr` varchar(1023) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `activity_day` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `activity_name`, `activity_img`, `activity_descr`, `activity_day`) VALUES
(1, 'Corso Pizzaiolo', '_immagini\\Pizzeria\\pizzaioli-senza-frontiere-corso-pizzaiolo-roseto-abruzzo.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nunc odio, consequat a metus sollicitudin, aliquam viverra felis. In ipsum arcu, dapibus sagittis nulla gravida, ultricies dignissim nulla. Ut sagittis lectus velit, et suscipit mauris elementum sed. Pellentesque nulla enim, ornare a metus gravida, varius pulvinar lorem', 'Ogni Lunedì Mattina!');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `review` varchar(511) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `title`, `review`) VALUES
(1, 'Ma che bella pizza', 'commento 1'),
(2, 'che bel titolo', 'oh, un commento'),
(20, '', ''),
(21, '', ''),
(22, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int NOT NULL,
  `pizza_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(2047) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `pizza_name`, `description`, `img`, `alt_text`) VALUES
(1, 'La nostra Margherita', 'Morbi mollis accumsan neque, sed congue odio ultrices non. Morbi sed mi vel tellus maximus vestibulum. Duis sagittis elementum orci, vel pharetra lorem pharetra in. Nullam quis sapien in nulla sodales vulputate sit amet non est. Maecenas arcu mauris, feugiat vel nibh in, elementum efficitur ante. Integer dapibus fringilla ex at lacinia. Nulla nec sapien in nulla scelerisque blandit vel non nulla. Duis sed metus in ante mollis tincidunt tempus sed ipsum.', '_immagini\\Pizzeria\\margherita-pizza-2021-08-29-00-57-47-utc.jpg', 'immagine margherita'),
(2, 'La nostra Marinara', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin suscipit dui ligula, vitae porttitor ligula congue at. Praesent sit amet ullamcorper est, eu lobortis elit. Phasellus rhoncus tincidunt tellus ut molestie. Vivamus luctus dui eu enim tempus, vel ornare ante pretium. Aenean convallis mi eget tempor pulvinar. Suspendisse at odio ornare, pulvinar neque id, vestibulum quam. Integer quis nisi mollis, fringilla velit laoreet, suscipit nulla. Aenean eget purus ac orci laoreet consequat nec quis dui. Pellentesque sollicitudin nunc a enim aliquam pharetra.', '_immagini\\Pizzeria\\pizza-margherita-2021-08-26-16-15-55-utc.jpg', 'immagine marinara');

-- --------------------------------------------------------

--
-- Table structure for table `pizza_imgs`
--

CREATE TABLE `pizza_imgs` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pizza_imgs`
--

INSERT INTO `pizza_imgs` (`id`, `title`, `img`) VALUES
(1, 'margherita-pizza-2021-08-29-00-57-47', '_immagini\\Pizzeria\\margherita-pizza-2021-08-29-00-57-47-utc.jpg'),
(2, 'pizza-margherita-2021-08-26-16-15-55', '_immagini\\Pizzeria\\pizza-margherita-2021-08-26-16-15-55-utc.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(1023) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `description`, `img`) VALUES
(1, 'Pizzaiolo 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In nec dictum eros, eu pretium neque. Ut justo nisi, feugiat eget risus a, venenatis placerat augue. Nullam interdum neque non egestas tempus. Donec varius semper malesuada. Etiam vel turpis accumsan, aliquet turpis non, finibus tellus. Phasellus ac lacus tincidunt, venenatis tortor sed, tempor mi. Aenean mi orci, mollis id volutpat ut, venenatis sed risus.', '_immagini\\Pizzeria\\smiling-bearded-pizzaiolo-holding-fresh-baked-mout-2021-12-09-15-26-13-utc.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `we_are`
--

CREATE TABLE `we_are` (
  `id` int NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `article_1` varchar(1023) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `article_2` varchar(511) NOT NULL,
  `article_3` varchar(511) NOT NULL,
  `img_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img_2` varchar(255) NOT NULL,
  `img_3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `we_are`
--

INSERT INTO `we_are` (`id`, `logo`, `article_1`, `article_2`, `article_3`, `img_1`, `img_2`, `img_3`) VALUES
(1, '_immagini\\Pizzeria\\LOGO.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nunc odio, consequat a metus sollicitudin, aliquam viverra felis. In ipsum arcu, dapibus sagittis nulla gravida, ultricies dignissim nulla. Ut sagittis lectus velit, et suscipit mauris elementum sed. Pellentesque nulla enim, ornare a metus gravida, varius pulvinar lorem. Morbi quis ligula mollis, efficitur lorem ut, maximus lectus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod scelerisque diam, a vestibulum nisl pharetra quis. Sed ac elit ligula. Donec hendrerit tincidunt mauris, sed tempus metus suscipit pretium.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod scelerisque diam, a vestibulum nisl pharetra quis. Sed ac elit ligula. Donec hendrerit tincidunt mauris, sed tempus metus suscipit pretium.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod scelerisque diam, a vestibulum nisl pharetra quis. Sed ac elit ligula. Donec hendrerit tincidunt mauris, sed tempus metus suscipit pretium.', '_immagini\\Pizzeria\\9389fc336a7e7c776184bf72134627ed.jpg', '_immagini\\Pizzeria\\baked-tasty-margherita-pizza-getting-out-of-the-ov-2021-09-03-16-49-23-utc.jpg', '_immagini\\Pizzeria\\bearded-pizzaiolo-chef-lunching-dough-into-air-2021-08-26-16-37-08-utc.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pizza_imgs`
--
ALTER TABLE `pizza_imgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `we_are`
--
ALTER TABLE `we_are`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pizza_imgs`
--
ALTER TABLE `pizza_imgs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `we_are`
--
ALTER TABLE `we_are`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
