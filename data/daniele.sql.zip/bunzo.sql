-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Nov 02, 2021 alle 13:25
-- Versione del server: 8.0.25
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bunzo`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `datetime` datetime(6) NOT NULL,
  `readtime` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `articles`
--

INSERT INTO `articles` (`id`, `author`, `title`, `img`, `description`, `alt`, `datetime`, `readtime`, `ord`) VALUES
(1, 'Autore1', 'Titolo1', '/assets/images/hero/home-3-hero-image-01.jpg', 'Testo1', 'Alt1', '2021-11-09 00:00:14.000000', 'Tempo1', 1),
(2, 'Autore2', 'Titolo2', '/assets/images/hero/home-4-hero-image-01.jpg', 'Testo2', 'Alt2', '2021-11-15 00:00:14.000000', 'Tempo2', 2),
(3, 'Autore3', 'Titolo3', '/assets/images/hero/home-3-hero-image-01.jpg', 'Testo3', 'Alt3', '2021-11-29 00:01:05.000000', 'Tempo3', 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `categories`
--

INSERT INTO `categories` (`id`, `title`, `url`, `alt`) VALUES
(1, 'Cat1', 'Url1', 'Alt1'),
(2, 'Cat2', 'Url2', 'Alt2'),
(3, 'Cat3', 'Url3', 'Alt3'),
(4, 'Cat4', 'Url4', 'Alt4');

-- --------------------------------------------------------

--
-- Struttura della tabella `footer_1`
--

CREATE TABLE `footer_1` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `footer_1`
--

INSERT INTO `footer_1` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Titolo1', 'Link1', 'Alt1', 1),
(2, 'Titolo2', 'Link2', 'Alt2', 2),
(3, 'Titolo3', 'Link3', 'Alt3', 3),
(4, 'Titolo4', 'Link4', 'Alt4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `footer_2`
--

CREATE TABLE `footer_2` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `footer_2`
--

INSERT INTO `footer_2` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Titolo1', 'Link1', 'Alt1', 1),
(2, 'Titolo2', 'Link2', 'Alt2', 2),
(3, 'Titolo3', 'Link3', 'Alt3', 3),
(4, 'Titolo4', 'Link4', 'Alt4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Titolo1', 'Url1', 'Alt1', 1),
(2, 'Titolo2', 'Url2', 'Alt2', 2),
(3, 'Titolo3', 'Url3', 'Alt3', 3),
(4, 'Titolo4', 'Url4', 'Alt4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `readtime` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `news`
--

INSERT INTO `news` (`id`, `author`, `title`, `readtime`, `img`, `datetime`, `alt`, `ord`) VALUES
(1, 'Autore1', 'Titolo1', 'Tempo1', '\\assets\\images\\populer/01_populer.jpg', '2021-10-28 15:08:30', 'Alt1', 1),
(2, 'Autore2', 'Titolo2', 'Tempo2', '\\assets\\images\\populer/02_populer.jpg', '2021-10-28 15:08:30', 'Alt2', 2),
(3, 'Autore3', 'Titolo3', 'Tempo3', '\\assets\\images\\populer/03_populer.jpg', '2021-10-28 15:08:30', 'Alt3', 3),
(4, 'Autore4', 'Titolo4', 'Tempo4', '\\assets\\images\\populer/01_populer.jpg', '2021-10-28 15:08:30', 'Alt4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `partners`
--

CREATE TABLE `partners` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `partners`
--

INSERT INTO `partners` (`id`, `title`, `img`, `url`, `alt`, `ord`) VALUES
(1, 'Nome1', '/assets/images/partners/01-partners.png', 'Url1', 'Alt1', 1),
(2, 'Nome2', '/assets/images/partners/02-partners.png', 'Url2', 'Alt2', 2),
(3, 'Nome3', '/assets/images/partners/03-partners.png', 'Url3', 'Alt3', 3),
(4, 'Nome4', '/assets/images/partners/04-partners.png', 'Url4', 'Alt4', 4),
(5, 'Nome5', '/assets/images/partners/01-partners.png', 'Url5', 'Alt5', 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `socials`
--

CREATE TABLE `socials` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `socials`
--

INSERT INTO `socials` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Nome1', 'Link1', 'Alt1', 1),
(2, 'Nome2', 'Link2', 'Alt2', 2),
(3, 'Nome3', 'Link3', 'Alt3', 3),
(4, 'Nome4', 'Link4', 'Alt4', 4);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `footer_1`
--
ALTER TABLE `footer_1`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `footer_2`
--
ALTER TABLE `footer_2`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `footer_1`
--
ALTER TABLE `footer_1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `footer_2`
--
ALTER TABLE `footer_2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `socials`
--
ALTER TABLE `socials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
