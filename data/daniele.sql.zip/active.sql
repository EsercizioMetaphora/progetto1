-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Nov 09, 2021 alle 17:04
-- Versione del server: 8.0.26
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `active`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `abbonamenti`
--

CREATE TABLE `abbonamenti` (
  `id` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `prezzo` varchar(255) NOT NULL,
  `durata` varchar(255) NOT NULL,
  `ord` int NOT NULL,
  `slug` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `abbonamenti`
--

INSERT INTO `abbonamenti` (`id`, `nome`, `prezzo`, `durata`, `ord`, `slug`) VALUES
(1, 'Active Base', '50 ', 'Mensile', 1, 1),
(2, 'Active Medium', '120', 'Trimestrale', 2, 2),
(3, 'Active Full', '400', 'Annuale', 3, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `corsi`
--

CREATE TABLE `corsi` (
  `id` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `trainer` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `giorno` varchar(255) NOT NULL,
  `orario` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL,
  `slug` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `corsi`
--

INSERT INTO `corsi` (`id`, `nome`, `trainer`, `img`, `giorno`, `orario`, `alt`, `ord`, `slug`) VALUES
(1, 'Ginnastica', 'Tommaso e Sara', '/_immagini/gymnastics-2021-09-24-03-26-28-utc.jpg', 'Tutti i giorni', '', 'Corso Ginnastica', 1, 1),
(2, 'Yoga', 'Lorena', '/_immagini/yoga-session-at-home-2021-08-26-15-32-19-utc.jpg', 'Lunedi', '18:00', 'Corso Yoga', 2, 2),
(3, 'Pesistica', 'Giovanni', '/_immagini/bodybuilder-working-out-in-gym-2021-08-30-02-29-31-utc.jpg', 'Tutti i giorni', '', 'Pesistica con istruttori dedicati', 3, 3),
(4, 'Arti Marziali', 'Luca e Ilaria', '/_immagini/woman-performing-martial-arts-high-kick-at-fight-c-2021-08-29-01-35-40-utc.jpg', 'Mercoledi', '18:00', 'Corso di Arti Marziali', 4, 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Home', '/index.php', 'Pagina iniziale', 1),
(2, 'Corsi', '/corsi.php', 'Corsi Palestra', 2),
(3, 'Trainers', '/trainers.php', 'Trainers Palestra', 3),
(4, 'Abbonamenti', '/abbonamenti.php', 'Abbonamenti Palestra', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `trainers`
--

CREATE TABLE `trainers` (
  `id` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `corsi` varchar(255) NOT NULL,
  `ord` int NOT NULL,
  `slug` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `trainers`
--

INSERT INTO `trainers` (`id`, `nome`, `img`, `info`, `corsi`, `ord`, `slug`) VALUES
(1, 'Tommaso', '/_immagini/personaltrainer_tommaso.jpg', 'INFO TOMMASO', 'CORSI DI TOMMASO', 1, 1),
(2, 'LUCA', '/_immagini/personaltrainer_luca.jpg', 'INFO LUCA', 'CORSI DI LUCA', 2, 2),
(3, 'Giovanni', '/_immagini/personaltrainer_giovanni.jpg', 'INFO GIOVANNI', 'CORSI DI GIOVANNI', 3, 3),
(4, 'SARA', '/_immagini/personaltrainer_sara.jpg', 'INFO SARA', 'CORSI DI SARA', 4, 4),
(5, 'Lorena', '/_immagini/personaltrainer_lorena.jpg', 'INFO LORENA', 'CORSI DI LORENA', 5, 5),
(6, 'ILARIA', '/_immagini/personaltrainer_ilaria.jpg', 'INFO ILARIA', 'CORSI DI ILARIA', 6, 6);

-- --------------------------------------------------------

--
-- Struttura della tabella `translations`
--

CREATE TABLE `translations` (
  `id` int NOT NULL,
  `source` varchar(2000) NOT NULL,
  `target` varchar(2000) NOT NULL,
  `lang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `translations`
--

INSERT INTO `translations` (`id`, `source`, `target`, `lang`) VALUES
(1, 'Home.Iscriviti.Subito', 'Iscriviti Subito', 'it'),
(2, 'Home.Nuova.Apertura', 'Nuova Apertura: Alias Active', 'it'),
(3, 'Home.Vi.Presentiamo.I.Nostri.Trainers', 'Vi presentiamo i nostri trainers', 'it'),
(4, 'Home.Prezzi.Competitivi', 'Prezzi Competitivi', 'it'),
(5, 'Home.Scegli.Il.Tuo.Piano', 'Scegli il tuo Piano', 'it'),
(6, 'Home.I.Nostri.Prezzi.Abbonamenti', 'I Nostri prezzi', 'it'),
(7, 'Home.Ci.Troviamo.Qui', 'CI TROVIAMO QUI', 'it'),
(8, 'Home.Telefono', 'Telefono', 'it'),
(9, 'Home.Numero.Telefono1', '2835627356', 'it'),
(10, 'Home.Numero.Telefono2', '27352357275', 'it'),
(11, 'Home.Indirizzo', 'Indirizzo', 'it'),
(12, 'Home.Indirizzo.Castello', 'Castello di Hogwarths, 6', 'it');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `abbonamenti`
--
ALTER TABLE `abbonamenti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `corsi`
--
ALTER TABLE `corsi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `abbonamenti`
--
ALTER TABLE `abbonamenti`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `corsi`
--
ALTER TABLE `corsi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `trainers`
--
ALTER TABLE `trainers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la tabella `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
