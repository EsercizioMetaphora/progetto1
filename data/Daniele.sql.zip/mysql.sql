-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Ott 25, 2021 alle 16:17
-- Versione del server: 8.0.25
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--
CREATE DATABASE IF NOT EXISTS `demo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `demo`;

-- --------------------------------------------------------

--
-- Struttura della tabella `article`
--

CREATE TABLE `article` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `article`
--

INSERT INTO `article` (`id`, `img`, `name`, `description`, `category`, `alt`, `price`, `ord`) VALUES
(1, '/images/immagini/IMG_4175.jpg', 'Nome1', 'Descrizione1', '0', 'Immagine1', '1', 1),
(2, '/images/immagini/IMG_4175.jpg', 'Nome2', 'Descrizione2', '0', 'Immagine2', '2', 2),
(3, '/images/immagini/IMG_4175.jpg', 'Nome3', 'Descrizione3', '1', 'Immagine3', '3', 3),
(4, '/images/immagini/IMG_4175.jpg', 'Nome4', 'Descrizione4', '1', 'Immagine4', '4', 4),
(5, '/images/immagini/IMG_4175.jpg', 'Nome5', 'Descrizione5', '2', 'Immagine5', '5', 5),
(6, '/images/immagini/IMG_4175.jpg', 'Nome6', 'Descrizione6', '2', 'Immagine6', '6', 6);

-- --------------------------------------------------------

--
-- Struttura della tabella `article_photo`
--

CREATE TABLE `article_photo` (
  `id` int NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `article_id` int NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `article_photo`
--

INSERT INTO `article_photo` (`id`, `img`, `alt`, `article_id`, `ord`) VALUES
(1, '/images/immagini/IMG_4175.jpg', 'Immagine1', 1, 1),
(2, '/images/immagini/IMG_4175.jpg', 'Immagine2', 1, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `carousel`
--

CREATE TABLE `carousel` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL,
  `active` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `alt`, `ord`, `active`) VALUES
(1, '/images/carousel/IMG_4139.jpg', 'Immagine 1', 1, b'1'),
(2, '/images/carousel/IMG_4139a.jpg', 'Immagine 2', 2, b'1'),
(3, '/images/carousel/IMG_4139b.jpg', 'Immagine 3', 3, b'1'),
(4, '/images/carousel/IMG_4140.jpg', 'Immagine 4', 4, b'0');

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `titolo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `titolo`, `url`, `alt`, `ord`) VALUES
(1, 'Home', '/index.php', 'Homepage', 1),
(2, 'List', '/list.php', 'Elenco Prodotti', 2),
(3, 'Details', '/details.php', 'Dettaglio Prodotti', 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `news`
--

INSERT INTO `news` (`id`, `img`, `alt`, `title`, `description`, `date`) VALUES
(1, '/images/news/IMG_4155.jpg', 'Immagine1', 'Titolo1', 'Testo1', '2021-10-14 15:15:30'),
(2, '/images/news/IMG_4155.jpg', 'Immagine2', 'Titolo2', 'Testo2', '2021-10-14 15:15:30'),
(3, '/images/news/IMG_4155.jpg', 'Immagine3', 'Titolo3', 'Testo3', '2021-10-14 15:19:05'),
(4, '/images/news/IMG_4155.jpg', 'Immagine4', 'Titolo4', 'Testo4', '2021-10-14 15:19:23');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `article_photo`
--
ALTER TABLE `article_photo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_photo_article` (`article_id`);

--
-- Indici per le tabelle `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `article`
--
ALTER TABLE `article`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la tabella `article_photo`
--
ALTER TABLE `article_photo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `article_photo`
--
ALTER TABLE `article_photo`
  ADD CONSTRAINT `articles_photo_article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
