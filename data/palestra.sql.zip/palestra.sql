-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Nov 09, 2021 at 05:04 PM
-- Server version: 8.0.27
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `palestra`
--

-- --------------------------------------------------------

--
-- Table structure for table `abbonamenti`
--

CREATE TABLE `abbonamenti` (
  `id` int NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `durata` int NOT NULL,
  `prezzo` int NOT NULL,
  `descrizione` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `abbonamenti`
--

INSERT INTO `abbonamenti` (`id`, `tipo`, `durata`, `prezzo`, `descrizione`) VALUES
(1, 'Mensile', 30, 30, 'Un fantastico abbonamento mensile!'),
(2, 'Trimestrale', 90, 25, 'Un fantastico abbonamento trimestrale!'),
(3, 'Annuale', 365, 20, 'Un fantastico abbonamento annuale!');

-- --------------------------------------------------------

--
-- Table structure for table `corsi`
--

CREATE TABLE `corsi` (
  `id` int NOT NULL,
  `nome_corso` varchar(255) NOT NULL,
  `data_ora` varchar(255) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `corsi`
--

INSERT INTO `corsi` (`id`, `nome_corso`, `data_ora`, `descrizione`, `img`, `alt_text`) VALUES
(1, 'Yoga', 'Lunedì alle 18:00', 'Descrizione 1\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. In pretium ipsum ut dolor congue, id dignissim leo venenatis. Phasellus a pulvinar eros, laoreet ultrices felis.', '/_immagini\\yoga-session-at-home-2021-08-26-15-32-19-utc.jpg', 'gente che fa yoga'),
(2, 'Arti Marziali', 'Mercoledì alle 18:00', 'Descrizione 2\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. In pretium ipsum ut dolor congue, id dignissim leo venenatis. Phasellus a pulvinar eros, laoreet ultrices felis.', '/_immagini\\martial-arts-fighters-hone-their-skills-2021-08-26-16-26-07-utc.jpg', 'gente che si pesta'),
(3, 'Pesistica', 'Su appuntamento', 'Descrizione 3\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. In pretium ipsum ut dolor congue, id dignissim leo venenatis. Phasellus a pulvinar eros, laoreet ultrices felis.', '/_immagini\\handsome-bodybuilder-concentrated-on-training-2021-09-24-03-47-48-utc.jpg', 'gente che solleva pesi'),
(4, 'Ginnastica per tutte le età', 'Da organizzare a seconda delle disponibilità', 'Descrizione 4\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. In pretium ipsum ut dolor congue, id dignissim leo venenatis. Phasellus a pulvinar eros, laoreet ultrices felis.', '/_immagini\\senior-people-workout-with-personal-trainer-in-reh-2021-08-30-00-36-03-utc.jpg', 'gente di ogni età che fa esercizio');

-- --------------------------------------------------------

--
-- Table structure for table `personal_trainer`
--

CREATE TABLE `personal_trainer` (
  `id` int NOT NULL,
  `nome` varchar(63) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `personal_trainer`
--

INSERT INTO `personal_trainer` (`id`, `nome`, `descrizione`, `img`) VALUES
(1, 'Giovanni', 'Giovanni, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_giovanni.jpg'),
(2, 'Ilaria', 'Ilaria, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_ilaria.jpg'),
(3, 'Lorena', 'Lorena, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_lorena.jpg'),
(4, 'Luca', 'Luca, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_luca.jpg'),
(5, 'Sara', 'Sara, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_sara.jpg'),
(6, 'Tommaso', 'Tommaso, lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et tortor mattis, auctor mauris ut, tristique magna. Donec sed urna dolor.', '/_immagini\\personaltrainer_tommaso.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE `social` (
  `id` int NOT NULL,
  `soc_name` varchar(255) NOT NULL,
  `personal_trainer_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `soc_name`, `personal_trainer_id`) VALUES
(1, 'facebook', 1),
(2, 'facebook', 2),
(3, 'facebook', 3),
(4, 'facebook', 4),
(5, 'facebook', 5),
(6, 'facebook', 6),
(7, 'twitter', 1),
(8, 'twitter', 2),
(9, 'twitter', 3),
(10, 'twitter', 4),
(11, 'twitter', 5),
(12, 'twitter', 6),
(13, 'linkedin', 1),
(14, 'linkedin', 2),
(15, 'linkedin', 5);

-- --------------------------------------------------------

--
-- Table structure for table `translation`
--

CREATE TABLE `translation` (
  `id` int NOT NULL,
  `source` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `language` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abbonamenti`
--
ALTER TABLE `abbonamenti`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `corsi`
--
ALTER TABLE `corsi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_trainer`
--
ALTER TABLE `personal_trainer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `translation`
--
ALTER TABLE `translation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abbonamenti`
--
ALTER TABLE `abbonamenti`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `corsi`
--
ALTER TABLE `corsi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_trainer`
--
ALTER TABLE `personal_trainer`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `translation`
--
ALTER TABLE `translation`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
