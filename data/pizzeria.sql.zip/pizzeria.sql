-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Dic 13, 2021 alle 11:49
-- Versione del server: 8.0.26
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizzeria`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Home', '/index.php', 'Pagina Iniziale', 1),
(2, 'Storia', '/story.php', 'Storia', 2),
(3, 'Pizzaioli', '/pizzaioli.php', 'Pizzaioli', 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `pizzaioli`
--

CREATE TABLE `pizzaioli` (
  `id` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL,
  `slug` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `pizzaioli`
--

INSERT INTO `pizzaioli` (`id`, `nome`, `img`, `descrizione`, `alt`, `ord`, `slug`) VALUES
(1, 'Daniele', '/_immagini/Pizzeria/unnamed.jpg', '', 'Daniele', 1, 1),
(2, 'Marco', '/_immagini/Pizzeria/smiling-bearded-pizzaiolo-holding-fresh-baked-mout-2021-12-09-15-26-13-utc.jpg', '', 'Marco', 2, 2),
(3, 'Luigi', '/_immagini/Pizzeria/handsome-pizzaiolo-making-pizza-at-kitchen-in-pizz-2021-08-26-16-21-11-utc (1).jpg', '', 'Luigi', 3, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `pizze`
--

CREATE TABLE `pizze` (
  `id` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL,
  `slug` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `pizze`
--

INSERT INTO `pizze` (`id`, `nome`, `img`, `descrizione`, `alt`, `ord`, `slug`) VALUES
(1, 'Margherita', '/_immagini/Pizzeria/top-view-of-pizza-margherita-on-gray-surface-2021-09-03-08-47-17-utc.jpg', '(Pomodoro,Mozzarella)', 'Pizza Margherita', 1, 1),
(2, 'Marinara', '/_immagini/Pizzeria/top-view-of-pizza-margherita-on-gray-surface-2021-09-03-08-50-11-utc.jpg', '(Pomodoro,Aglio,Origano)', 'Pizza Marinara', 2, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `translations`
--

CREATE TABLE `translations` (
  `id` int NOT NULL,
  `source` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `lang` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `translations`
--

INSERT INTO `translations` (`id`, `source`, `target`, `lang`) VALUES
(1, 'Home.Nuova.Apertura', 'Nuova Apertura: A Tutta Pizza', 'it'),
(2, 'Home.Corsi', 'Ogni Lunedì mattina organizziamo il nostro corso per fare la pizza', 'it'),
(3, 'Home.Apertura.Locale', 'Siamo aperti tutti i giorni dalle 11 alle 16 e dalle 18 alle 23', 'it'),
(4, 'Home.Vieni.a.Conoscerci', 'Vieni a conoscerci', 'it'),
(5, 'Home.Telefono', 'TELEFONO', 'it'),
(6, 'Home.Numero.Telefono1', '3534634667', 'it'),
(7, 'Home.Numero.Telefono2', '27346287356', 'it'),
(8, 'Home.Indirizzo', 'INDIRIZZO', 'it'),
(9, 'Home.Indirizzo.Pizzeria', 'Via Roma, 10 Arezzo', 'it');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `pizzaioli`
--
ALTER TABLE `pizzaioli`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `pizze`
--
ALTER TABLE `pizze`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `pizzaioli`
--
ALTER TABLE `pizzaioli`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `pizze`
--
ALTER TABLE `pizze`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
