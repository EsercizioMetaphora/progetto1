-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Oct 28, 2021 at 04:03 PM
-- Server version: 8.0.27
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `BunzoF`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `art_date` date NOT NULL,
  `read_time` varchar(31) NOT NULL,
  `slide_view` tinyint(1) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `autor_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `titolo`, `testo`, `img`, `art_date`, `read_time`, `slide_view`, `alt`, `autor_id`) VALUES
(1, 'All of these amazing features                                come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 1, '', 1),
(2, 'Create beautiful designs that will help convert more...', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 1, '', 1),
(3, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 0, '', 1),
(4, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 0, '', 1),
(5, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 0, '', 1),
(6, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '10 min read', 0, '', 1),
(7, 'WooLentor is a powerful WordPress plugin for WooCommerce', 'That necessitates a robust ecommerce platform that optimizes your store & products', '\\assets\\images\\recent-article\\01-recent-article.jpg', '2021-04-03', '14 min read', 1, '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `article_autor`
--

CREATE TABLE `article_autor` (
  `id` int NOT NULL,
  `nome` varchar(31) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cognome` varchar(31) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article_autor`
--

INSERT INTO `article_autor` (`id`, `nome`, `cognome`, `url`) VALUES
(1, 'Julian', 'Marshall', '#'),
(2, 'Nathan', 'Non Ricodo Il Cognome', '#');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `titolo`, `url`, `ord`) VALUES
(1, 'wooCommerce', '#', 1),
(2, 'UI/UX Design', '#', 5),
(3, 'Magento', '#', 3),
(4, 'Laravel', '#', 4),
(5, 'Online Tutorial', '#', 6),
(6, 'JavaScript', '#', 7),
(7, 'Lifestyle', '#', 8),
(8, 'Marketing', '#', 9),
(9, 'WordPress', '#', 10);

-- --------------------------------------------------------

--
-- Table structure for table `footer_nav`
--

CREATE TABLE `footer_nav` (
  `id` int NOT NULL,
  `titolo` varchar(63) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `footer_nav`
--

INSERT INTO `footer_nav` (`id`, `titolo`, `url`) VALUES
(1, 'link1', '#'),
(2, 'link2', '#'),
(3, 'link3', '#'),
(4, 'link4', '#');

-- --------------------------------------------------------

--
-- Table structure for table `footer_nav2`
--

CREATE TABLE `footer_nav2` (
  `id` int NOT NULL,
  `titolo` varchar(63) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `footer_nav2`
--

INSERT INTO `footer_nav2` (`id`, `titolo`, `url`) VALUES
(1, 'link 1 ', '#'),
(2, 'link 2 ', '#'),
(3, 'link 3 ', '#');

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL,
  `titolo` varchar(63) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `url`, `titolo`, `alt`, `ord`) VALUES
(1, '/index.php', 'Home', 'Home', 1),
(2, '#', 'cose diverse', 'cose diverse', 2),
(3, '#', 'altre cose', 'altre cose', 3),
(4, '#', 'cose nuove', 'cose nuove', 4),
(5, '#', 'gnagno', 'gnagno', 5);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `url`, `img`) VALUES
(1, '#', 'assets/images/partners/01-partners.png'),
(2, '#', 'assets/images/partners/02-partners.png'),
(3, '#', 'assets/images/partners/03-partners.png'),
(4, '#', 'assets/images/partners/04-partners.png'),
(5, '#', 'assets/images/partners/05-partners.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_autor`
--
ALTER TABLE `article_autor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_nav`
--
ALTER TABLE `footer_nav`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_nav2`
--
ALTER TABLE `footer_nav2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `article_autor`
--
ALTER TABLE `article_autor`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `footer_nav`
--
ALTER TABLE `footer_nav`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `footer_nav2`
--
ALTER TABLE `footer_nav2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
