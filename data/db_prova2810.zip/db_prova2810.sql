-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Oct 28, 2021 at 04:01 PM
-- Server version: 8.0.27
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_prova2810`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `nome` varchar(31) NOT NULL,
  `step` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nome`, `step`) VALUES
(1, 'Woocommerce', 1),
(2, 'Wordpress', 1),
(3, 'Magento', 1),
(4, 'BlaBla', 1),
(5, 'Laravel', 1),
(6, 'Design', 2),
(7, 'Online tutorial', 2),
(8, 'Javascript', 2),
(9, 'Lifestyle', 2),
(10, 'Marketing', 3),
(11, 'Ciao', 3),
(12, 'Tutti', 3),
(13, 'Amici', 4),
(14, 'Cari', 4);

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu_footer`
--

CREATE TABLE `navigation_menu_footer` (
  `id` int NOT NULL,
  `nome` varchar(20) NOT NULL,
  `ordine` int NOT NULL,
  `tipo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu_footer`
--

INSERT INTO `navigation_menu_footer` (`id`, `nome`, `ordine`, `tipo`) VALUES
(1, 'footer1', 1, 1),
(2, 'footer2', 2, 1),
(5, 'footeracaso', 3, 1),
(6, 'ciaoatutti', 4, 1),
(9, 'Titolo22', 1, 2),
(10, 'titolo33', 2, 2),
(13, 'titolo44', 3, 2),
(14, 'acaso55', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu_header`
--

CREATE TABLE `navigation_menu_header` (
  `id` int NOT NULL,
  `nome` varchar(20) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu_header`
--

INSERT INTO `navigation_menu_header` (`id`, `nome`, `ord`) VALUES
(1, 'Titolo1', 1),
(2, 'Titolo2', 2),
(3, 'titolo3', 3),
(4, 'titolo4', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `autore` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `tempo_lettura` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `titolo`, `autore`, `img`, `data`, `tempo_lettura`) VALUES
(1, 'ciao a tutti amici vi voglio bene', 'cosimo matassini', 'assets/images/populer/01_populer.jpg', '2021-10-05', 10),
(2, 'ma tanto tanto bene', 'Jack Dwawestn', 'assets/images/populer/02_populer.jpg', '2021-10-07', 20),
(3, 'ciao a tuttiiiiiii!', 'Jack Dawson', 'assets/images/populer/02_populer.jpg', '2021-10-04', 5),
(4, 'HEllo eveRYBOdy how are u?', 'Cosimo Matassini', 'assets/images/populer/03_populer.jpg', '2021-10-13', 15);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `img`) VALUES
(1, 'assets/images/partners/01-partners.png'),
(2, 'assets/images/partners/02-partners.png'),
(3, 'assets/images/partners/03-partners.png'),
(4, 'assets/images/partners/04-partners.png');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `sottotitolo` varchar(255) NOT NULL,
  `autore` varchar(31) NOT NULL,
  `data` date NOT NULL,
  `tempo_lettura` int NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `titolo`, `sottotitolo`, `autore`, `data`, `tempo_lettura`, `img`) VALUES
(1, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'Andrew Hoffman', '2021-10-19', 10, 'assets/images/recent-article/02-recent-article.jpg'),
(2, 'Create beautiful designs that will help convert more...', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'Cosimo Matassini', '2021-07-15', 15, 'assets/images/recent-article/10-recent-article.jpg'),
(3, 'All of these amazing features are amazing!!', 'ciao a tutti io sono cosimo matassini e vi saluto', 'Andrew Hoffman', '2021-07-01', 5, 'assets/images/recent-article/01-recent-article.jpg'),
(4, 'Create beautiful designs that will help convert more...', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'Cosimo Matassini', '2021-10-04', 10, 'assets/images/recent-article/05-recent-article.jpg'),
(5, 'All of these amazing features come at an affordable price!', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'Jack Dawson', '2021-08-26', 10, 'assets/images/recent-article/08-recent-article.jpg'),
(6, 'Create beautiful designs that will help convert more...', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', 'Cosimo Matassini', '2021-09-01', 20, 'assets/images/recent-article/03-recent-article.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `id` int NOT NULL,
  `autore` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `sottotitolo` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `tempo_lettura` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`id`, `autore`, `titolo`, `sottotitolo`, `data`, `tempo_lettura`) VALUES
(1, 'Julian Marshall', 'WooLentor is a powerful WordPress plugin for WooCommerce', 'That necessitates a robust ecommerce platform that optimizes your store & products', '2021-04-03', 10),
(2, 'Andrew Hoffman', 'All of these amazing features come at an affordable price!', 'That necessitates a robust ecommerce platform that optimizes your store & products', '2021-04-03', 10),
(5, 'Cosimo Matassini', 'is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy', 'text ever since the 1500s, when an unknown printer took a galley', '2021-04-03', 20);

-- --------------------------------------------------------

--
-- Table structure for table `socialnet`
--

CREATE TABLE `socialnet` (
  `id` int NOT NULL,
  `socialname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `socialnet`
--

INSERT INTO `socialnet` (`id`, `socialname`, `link`) VALUES
(1, 'facebook', 'https://www.facebook.com/'),
(2, 'twitter', 'https://www.twitter.com/'),
(3, 'skype', 'https://www.skype.com/'),
(4, 'linkedin', 'https://www.linkedin.com/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu_footer`
--
ALTER TABLE `navigation_menu_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu_header`
--
ALTER TABLE `navigation_menu_header`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socialnet`
--
ALTER TABLE `socialnet`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `navigation_menu_footer`
--
ALTER TABLE `navigation_menu_footer`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `socialnet`
--
ALTER TABLE `socialnet`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
