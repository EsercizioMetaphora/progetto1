-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Ott 28, 2021 alle 16:12
-- Versione del server: 8.0.25
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `provapratica_281021`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `banner`
--

CREATE TABLE `banner` (
  `id` int NOT NULL,
  `text` varchar(255) NOT NULL,
  `url_button` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `banner`
--

INSERT INTO `banner` (`id`, `text`, `url_button`, `title`) VALUES
(1, 'Lorem Ipsum is simply dummy text themes', 'http://localhost:8009/index.php#', 'Lorem ipsum dolor sit amet, consectetur adipiscing eli.');

-- --------------------------------------------------------

--
-- Struttura della tabella `form`
--

CREATE TABLE `form` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `url`, `text`) VALUES
(1, 'http://localhost:8009/url.html', 'Menu di prova'),
(2, 'http://localhost:8009/url.html', 'Menu di prova'),
(3, 'http://localhost:8009/url.html', 'Menu di prova'),
(4, 'http://localhost:8009/url.html', 'Menu di prova');

-- --------------------------------------------------------

--
-- Struttura della tabella `news_week`
--

CREATE TABLE `news_week` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `read_time` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `news_week`
--

INSERT INTO `news_week` (`id`, `title`, `text`, `img`, `read_time`, `date`) VALUES
(1, 'All of these amazing features\r\n                                                come at an affordable price!', '', 'images/news/news1.jpg', '10 min read', '03 April, 2021'),
(2, 'WooCommerce comes with an\r\n                                                intuitive drag-and-drop...', '', 'images/news/news2.jpg', '10 min read', '03 April, 2021'),
(3, 'Create beautiful designs that\r\n                                                will help convert more...', '', 'images/news/news3.jpg', '10 min read', '03 April, 2021');

-- --------------------------------------------------------

--
-- Struttura della tabella `partners`
--

CREATE TABLE `partners` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `partners`
--

INSERT INTO `partners` (`id`, `img`, `url`, `alt`) VALUES
(1, 'images/partner/01-partners.png', 'http://localhost:8009/index.php#!', ''),
(2, 'images/partner/02-partners.png', 'http://localhost:8009/index.php#!', ''),
(3, 'images/partner/03-partners.png', 'http://localhost:8009/index.php#!', ''),
(4, 'images/partner/04-partners.png', 'http://localhost:8009/index.php#!', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `post`
--

CREATE TABLE `post` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `time_read` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `category_id` int NOT NULL,
  `date_article` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `post`
--

INSERT INTO `post` (`id`, `title`, `img`, `author`, `text`, `time_read`, `url`, `category_id`, `date_article`) VALUES
(1, 'All of these amazing features come at an affordable price!', 'images/article/first_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '10 min read', 'http://localhost:8009/index.php#!', 6, '03 April, 2021'),
(2, 'Create beautiful designs that will help convert more...', 'images/article/second_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '10 min read', 'http://localhost:8009/index.php#!', 1, '03 April, 2021'),
(3, 'All of these amazing features come at an affordable price!', 'images/article/third_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '10 min read', 'http://localhost:8009/assets/images/recent-article/01-recent-article.jpg', 9, '03 April, 2021'),
(4, 'Create beautiful designs that will help convert more...', 'images/article/fourth_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.\r\n\r\n', '10 min read', 'http://localhost:8009/index.php#!', 10, '03 April, 2021'),
(5, 'All of these amazing features come at an affordable price!', 'images/article/fifth_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.\r\n\r\n', '10 min read', 'http://localhost:8009/index.php#!', 7, '03 April, 2021'),
(6, 'Create beautiful designs that will help convert more...', 'images/article/sixth_article.jpg', 'Andrew Hoffman', 'Lorem Ipsum is simply dummy text themes print industry orem psum has been them industry spa also the loep into type setting.', '10 min read', 'http://localhost:8009/index.php#!', 2, '03 April, 2021');

-- --------------------------------------------------------

--
-- Struttura della tabella `post_categories`
--

CREATE TABLE `post_categories` (
  `id` int NOT NULL,
  `description` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `post_categories`
--

INSERT INTO `post_categories` (`id`, `description`, `href`) VALUES
(1, 'WooCommerce', 'http://localhost:8009/index.php#'),
(2, 'WordPress', 'http://localhost:8009/index.php#'),
(3, 'Magento', 'http://localhost:8009/index.php#'),
(4, 'Laravel', 'http://localhost:8009/index.php#'),
(5, 'UI/UX Design', 'http://localhost:8009/index.php#'),
(6, 'Online Tutorial', 'http://localhost:8009/index.php#'),
(7, 'Javascript', 'http://localhost:8009/index.php#'),
(8, 'LifeStyle', 'http://localhost:8009/index.php#'),
(9, 'Marketing', 'http://localhost:8009/index.php#'),
(10, 'Magento', 'http://localhost:8009/index.php#'),
(11, 'UX Design', 'http://localhost:8009/index.php#');

-- --------------------------------------------------------

--
-- Struttura della tabella `slideshow`
--

CREATE TABLE `slideshow` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `date_article` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `reading_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `slideshow`
--

INSERT INTO `slideshow` (`id`, `img`, `date_article`, `link`, `author`, `title`, `text`, `reading_time`) VALUES
(1, 'images/slideshow/img_slideshow.jpg', '03 April, 2021', 'http://localhost:8009/blog-details.html', 'Julian Marshall', 'WooLentor is a powerfool wordpress plugin for WooCommerce', 'That necessitates a robust ecommerce platform that optimizes your store & products', '10 min read'),
(2, 'images/slideshow/img_slideshow.jpg', '03 April, 2021', 'http://localhost:8009/blog-details.html', 'Andrew Hoffman', 'All of these amazing features come at an affordable price!', 'That necessitates a robust ecommerce platform that optimizes your store & products', '10 min read'),
(3, 'images/slideshow/img_slideshow.jpg', '03 April, 2021', 'http://localhost:8009/blog-details.html', 'Andrew Hoffman', 'WooLentor is a powerful\r\n                                                    WordPress plugin for\r\n                                                    WooCommerce', 'That necessitates a robust ecommerce platform that\r\n                                                optimizes your store & products', '10 min read');

-- --------------------------------------------------------

--
-- Struttura della tabella `small_banner`
--

CREATE TABLE `small_banner` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `small_banner`
--

INSERT INTO `small_banner` (`id`, `title`, `sub_title`, `url`) VALUES
(1, 'Unlimited Advice, Tutorial & Resource', 'ALL SOLUTION IN ONE', 'http://localhost:8009/index.php#');

-- --------------------------------------------------------

--
-- Struttura della tabella `social`
--

CREATE TABLE `social` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `social`
--

INSERT INTO `social` (`id`, `url`) VALUES
(1, 'http://localhost:8009/index.php#'),
(2, 'http://localhost:8009/index.php#'),
(3, 'http://localhost:8009/index.php#'),
(4, 'http://localhost:8009/index.php#');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `news_week`
--
ALTER TABLE `news_week`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_category_id` (`category_id`);

--
-- Indici per le tabelle `post_categories`
--
ALTER TABLE `post_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `small_banner`
--
ALTER TABLE `small_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `form`
--
ALTER TABLE `form`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `news_week`
--
ALTER TABLE `news_week`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `post`
--
ALTER TABLE `post`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la tabella `post_categories`
--
ALTER TABLE `post_categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT per la tabella `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `small_banner`
--
ALTER TABLE `small_banner`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `social`
--
ALTER TABLE `social`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_category_id` FOREIGN KEY (`category_id`) REFERENCES `post_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
