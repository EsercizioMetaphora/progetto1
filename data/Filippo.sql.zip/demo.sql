-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Oct 27, 2021 at 01:11 PM
-- Server version: 8.0.25
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `category` int NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `name`, `description`, `img`, `price`, `category`, `alt`, `ord`) VALUES
(1, 'Nome 1', 'Descrizione 1', '/images/immagini/IMG_4175.jpg', 10, 0, 'cose a caso', 1),
(2, 'Nome 2', 'Descrizione 2', '/images/immagini/IMG_4175.jpg', 10, 0, 'cose a caso', 2),
(3, 'Nome 3', 'Descrizione 3', '/images/immagini/IMG_4175.jpg', 10, 1, 'cose a caso', 3),
(4, 'Nome 4', 'Descrizione 4', '/images/immagini/IMG_4175.jpg', 10, 1, 'cose a caso', 4),
(5, 'Nome 5', 'Descrizione 5', '/images/immagini/IMG_4175.jpg', 10, 2, '', 0),
(6, 'Nome 6', 'Descrizione 6', '/images/immagini/IMG_4175.jpg', 10, 2, '', 0),
(7, 'Nome 7', 'Descrizione 7', '/images/immagini/IMG_4175.jpg', 10, 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `article_photo`
--

CREATE TABLE `article_photo` (
  `id` int NOT NULL,
  `name` varchar(127) NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL,
  `article_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article_photo`
--

INSERT INTO `article_photo` (`id`, `name`, `img`, `alt`, `ord`, `article_id`) VALUES
(1, '', '/images/immagini/IMG_4175.jpg', '', 4, 1),
(2, '', '/images/immagini/IMG_4170.jpg', '', 2, 1),
(3, '', '/images/immagini/IMG_4155.jpg', '', 3, 1),
(4, '', '/images/immagini/IMG_4155a.jpg', '', 1, 1),
(5, '', '/images/immagini/IMG_4170.jpg', '', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE `carousel` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL,
  `active` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `alt`, `ord`, `active`) VALUES
(3, '/images/carousel/IMG_4139.jpg\r\n', 'è un portiere credo', 1, b'1'),
(4, '/images/carousel/IMG_4139a.jpg', 'forse è un altro portiere, ma probabilmente con i colori strampalati', 2, b'1'),
(5, '/images/carousel/IMG_4139b.jpg', 'credo sia ancora un portiere, ma forse maledetto da creature delle tenebre', 3, b'1'),
(6, '/images/carousel/IMG_4140.jpg', 'non ne ho idea', 4, b'1');

-- --------------------------------------------------------

--
-- Table structure for table `general_log`
--

CREATE TABLE `general_log` (
  `event_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `user_host` mediumtext NOT NULL,
  `thread_id` bigint UNSIGNED NOT NULL,
  `server_id` int UNSIGNED NOT NULL,
  `command_type` varchar(64) NOT NULL,
  `argument` mediumblob NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8mb3 COMMENT='General log';

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `titolo`, `url`, `alt`, `ord`) VALUES
(1, 'Home', '/index.php', 'Home Page', 1),
(2, 'List', '/list.php', 'Lista Prodotti', 2),
(3, 'Details', '/details.php', 'Dettagli prodotti', 3),
(4, 'pippo', '/pippo.php', 'pippotanto', 4),
(5, 'pippo 2', '/pippo_troppo.php', 'pippodavverotroppo', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` datetime NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `date`, `img`, `alt`, `ord`) VALUES
(1, 'titolo 1 ', 'testo 1', '2021-10-14 15:20:05', '/images/immagini/IMG_4155a.jpg', 'immagine 1, non so cosa ci sia raffigurato', 1),
(2, 'titolo 2 ', 'testo 2', '2021-10-14 15:20:05', '/images/immagini/IMG_4155.jpg', 'immagine 2, non so cosa ci sia raffigurato', 2),
(3, 'titolo 3 ', 'testo 3 molto impegnativo', '2021-10-14 15:20:05', '/images/immagini/IMG_4170.jpg', 'immagine 3, non so cosa ci sia raffigurato', 3),
(4, 'titolo 4 ', 'testo 4', '2021-10-14 15:20:05', '/images/immagini/IMG_4155a.jpg', 'immagine 4, non so cosa ci sia raffigurato', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_photo`
--
ALTER TABLE `article_photo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_photo_article` (`article_id`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `article_photo`
--
ALTER TABLE `article_photo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `article_photo`
--
ALTER TABLE `article_photo`
  ADD CONSTRAINT `article_photo_article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
