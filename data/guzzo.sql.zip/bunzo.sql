-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Ott 28, 2021 alle 16:00
-- Versione del server: 8.0.26
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bunzo`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `footer_1`
--

CREATE TABLE `footer_1` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `footer_1`
--

INSERT INTO `footer_1` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Nome1', 'Url1', 'Link1', 1),
(2, 'Nome2', 'Url2', 'Link2', 2),
(3, 'Nome3', 'Url3', 'Link3', 3),
(4, 'Nome4', 'Url4', 'Link4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `footer_2`
--

CREATE TABLE `footer_2` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `footer_2`
--

INSERT INTO `footer_2` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'BlaBlu', 'Link1', 'Alt1', 1),
(2, 'Blablu', 'Link2', 'Alt2', 2),
(3, 'BlaBlu', 'Link3', 'Alt3', 3),
(4, 'Blablu', 'Link4', 'Alt4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Titolo1', 'blabla', 'Menu1', 1),
(2, 'Titolo2', 'blablu', 'Menu2', 2),
(3, 'Titolo3', 'blabla', 'Menu3', 3),
(4, 'Titolo4', 'blablu', 'Menu4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `img`, `datetime`, `alt`, `ord`) VALUES
(1, 'Titolo1', 'Descrizione1', 'Immagine1', '2021-10-28 15:08:30', 'News1', 1),
(2, 'Titolo2', 'Descrizione2', 'Immagine2', '2021-10-28 15:08:30', 'News2', 2),
(3, 'Titolo3', 'Descrizione3', 'Immagine3', '2021-10-28 15:08:30', 'News3', 3),
(4, 'Titolo4', 'Descrizione4', 'Immagine4', '2021-10-28 15:08:30', 'News4', 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `partners`
--

CREATE TABLE `partners` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `partners`
--

INSERT INTO `partners` (`id`, `title`, `img`, `url`, `alt`, `ord`) VALUES
(1, 'nome1', 'Img1', 'url1', 'alt1', 1),
(2, 'nome2', 'Img2', 'url2', 'alt2', 2),
(3, 'nome3', 'img3', 'url3', 'alt3', 3),
(4, 'nome4', 'img4', 'url4', 'alt4', 4),
(5, 'nome5', 'img5', 'url5', 'alt5', 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `social_networks`
--

CREATE TABLE `social_networks` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `social_networks`
--

INSERT INTO `social_networks` (`id`, `title`, `url`, `alt`, `ord`) VALUES
(1, 'Nome1', 'Link1', 'Alt1', 1),
(2, 'Nome2', 'Link2', 'Alt2', 2),
(3, 'Nome3', 'Link3', 'Alt3', 3),
(4, 'Nome4', 'Link4', 'Alt4', 4);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `footer_1`
--
ALTER TABLE `footer_1`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `footer_2`
--
ALTER TABLE `footer_2`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `social_networks`
--
ALTER TABLE `social_networks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `footer_1`
--
ALTER TABLE `footer_1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `footer_2`
--
ALTER TABLE `footer_2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `social_networks`
--
ALTER TABLE `social_networks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
